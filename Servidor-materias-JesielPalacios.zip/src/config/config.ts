export default {
  
  jwtSecret: 'BDPE@',
  jwtSecretReset:'BDPE@123'

};